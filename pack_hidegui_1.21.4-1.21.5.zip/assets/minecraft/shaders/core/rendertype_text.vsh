#version 150

#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vec4 col = Color;
    vec3 c = round(Color.rgb * 255.0);

    bool ortho = abs(ProjMat[3][3] - 1.0) < 0.001;
    bool marked = c.r >= 154.0 && c.r <= 254.0 && c.g >= 250.0 && c.g <= 254.0 && c.b <= 100.0;

    if (ortho && marked) {
        float halfWidth = 1.0 / ProjMat[0][0];
        float height = 2.0 / abs(ProjMat[1][1]);

        pos.x += (c.r - 154.0) / 50.0 * halfWidth - halfWidth;
        pos.y += (height - 34.0) * c.b / 100.0;


        vec3 rgb = vec3(1.0);
        if (c.g == 250.0) rgb = vec3(85.0, 255.0, 85.0) / 255.0;
        else if (c.g == 251.0) rgb = vec3(255.0, 255.0, 85.0) / 255.0;
        else if (c.g == 252.0) rgb = vec3(255.0, 85.0, 85.0) / 255.0;
        else if (c.g == 253.0) rgb = vec3(170.0, 170.0, 170.0) / 255.0;
        col = vec4(rgb, Color.a);
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
}
