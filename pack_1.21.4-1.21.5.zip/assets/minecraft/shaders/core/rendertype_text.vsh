#version 150

#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;
uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// ---- animated buffer bar (должно совпадать с HudPlugin.java) ----
const float BAR_W = 100.0;       // ширина глифа buf_bar.png
const float BAR_Y = 30.0;        // y-percent (SHADER_BAR_Y)
const bool  BAR_RIGHT = true;    // справа (false = слева)
const float EASE_TICKS = 10.0;   // EASE_TICKS
const bool  FLIP_VERTEX_ORDER = false; // если полоска «растёт» не с той стороны - поставь true

void main() {
    vec3 pos = Position;
    vec4 col = Color;
    vec3 c = round(Color.rgb * 255.0);

    bool ortho = abs(ProjMat[3][3] - 1.0) < 0.001;
    bool marked = (c.r == 254.0 || c.r == 253.0) && c.g >= 250.0 && c.b <= 100.0;
    // данные полоски лежат в цвете: R = 0xF0|t[2:0], G = 0x80|t[3]<<6|from, B = t[4]<<6|to
    bool isBar = c.r >= 240.0 && c.r <= 247.0 && c.g >= 128.0 && c.b < 128.0;

    if (ortho && marked) {
        float halfWidth = 1.0 / ProjMat[0][0];
        float height = 2.0 / abs(ProjMat[1][1]);

        pos.x += c.r == 254.0 ? halfWidth : -halfWidth;
        pos.y += (height - 34.0) * c.b / 100.0;

        col = vec4(1.0, 1.0, 1.0, Color.a);
    } else if (ortho && isBar) {
        float halfWidth = 1.0 / ProjMat[0][0];
        float height = 2.0 / abs(ProjMat[1][1]);

        float t = c.r - 240.0;
        float from = c.g - 128.0;
        float to = c.b;
        float t3 = step(64.0, from);
        from -= 64.0 * t3;
        float t4 = step(64.0, to);
        to -= 64.0 * t4;
        t += 8.0 * t3 + 16.0 * t4;

        // GameTime = (игровой тик % 24000 + partialTick) / 24000: синхронизирован с сервером и плавный по кадрам.
        // 24000 кратно 32, поэтому mod 32 не ломается на переходе суток.
        float e = mod(GameTime * 24000.0 - t + 16.0, 32.0) - 16.0;   // тиков с начала анимации, [-16..16)
        float p = clamp(e / EASE_TICKS, 0.0, 1.0);
        float k = 1.0 - pow(1.0 - p, 3.0);                           // easeOutCubic
        float frac = mix(from, to, k) / 63.0;

        // квад глифа: вершины 0,1 слева, 2,3 справа. Правый край сдвигаем влево - текстура однородна по X, не видно
        bool right = (gl_VertexID % 4) >= 2;
        if (FLIP_VERTEX_ORDER) right = !right;
        if (right) pos.x -= BAR_W * (1.0 - frac);

        pos.x += BAR_RIGHT ? halfWidth : -halfWidth;
        pos.y += (height - 34.0) * BAR_Y / 100.0;

        col = vec4(1.0, 1.0, 1.0, Color.a);
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
