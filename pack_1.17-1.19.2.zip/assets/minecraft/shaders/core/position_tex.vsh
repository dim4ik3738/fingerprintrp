#version 150

in vec3 Position;
in vec2 UV0;

uniform sampler2D Sampler0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    texCoord0 = UV0;

    bool ortho = abs(ProjMat[3][3] - 1.0) < 0.001;
    if (ortho && textureSize(Sampler0, 0) == ivec2(256, 256)) {
        float cx = floor(1.0 / ProjMat[0][0]);
        float screenH = 2.0 / abs(ProjMat[1][1]);
        float v = UV0.y * 256.0;
        bool whiteRows = v > 59.5 && v < 70.5;
        bool barX = abs(Position.x - (cx - 91.0)) < 0.6
                 || abs(Position.x - (cx + 91.0)) < 0.6
                 || abs(Position.x - (cx + 92.0)) < 0.6;
        bool top = Position.y < screenH * 0.5;
        if (whiteRows && barX && top) {
            gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
        }
    }
}
