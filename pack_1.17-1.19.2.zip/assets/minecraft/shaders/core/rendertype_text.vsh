#version 150

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vec4 col = Color;

    vec3 c = round(Color.rgb * 255.0);
    bool ortho = abs(ProjMat[3][3] - 1.0) < 0.001;
    bool marked = c.r >= 154.0 && c.r <= 254.0 && c.g >= 250.0 && c.g <= 254.0 && c.b <= 100.0;

    if (ortho && marked) {
        float halfWidth = 1.0 / ProjMat[0][0];
        float height = 2.0 / abs(ProjMat[1][1]);

        pos.x += (c.r - 154.0) / 50.0 * halfWidth - halfWidth; // R = 154 + x%
        pos.y += (height - 34.0) * c.b / 100.0;

        // green channel picks the text colour: 250 green, 251 yellow, 252 red, 253 gray, else white
        vec3 rgb = vec3(1.0);
        if (c.g == 250.0) rgb = vec3(85.0, 255.0, 85.0) / 255.0;
        else if (c.g == 251.0) rgb = vec3(255.0, 255.0, 85.0) / 255.0;
        else if (c.g == 252.0) rgb = vec3(255.0, 85.0, 85.0) / 255.0;
        else if (c.g == 253.0) rgb = vec3(170.0, 170.0, 170.0) / 255.0;
        col = vec4(rgb, Color.a);
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    bool markedShadow = c.r == 63.0 && c.g == 63.0 && c.b <= 25.0 && c.b != 21.0;
    if (ortho && markedShadow) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    }

    vec3 view = (ModelViewMat * vec4(Position, 1.0)).xyz;
    vertexDistance = FogShape == 0 ? length(view) : max(length(view.xz), abs(view.y));
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
