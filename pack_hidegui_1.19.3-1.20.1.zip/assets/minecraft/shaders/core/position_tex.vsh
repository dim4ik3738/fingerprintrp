#version 150

in vec3 Position;
in vec2 UV0;

uniform sampler2D Sampler0;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec2 texCoord0;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    texCoord0 = UV0;
    if (abs(ProjMat[3][3] - 1.0) < 0.001) {
        gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
    }
}
