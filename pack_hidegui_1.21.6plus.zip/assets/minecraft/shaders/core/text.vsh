#version 330




#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vec4 col = Color;

    vec3 c = round(Color.rgb * 255.0);
    bool ortho = abs(ProjMat[3][3] - 1.0) < 0.001;
    bool marked = c.r >= 154.0 && c.r <= 254.0 && c.g >= 250.0 && c.g <= 254.0 && c.b <= 100.0;

    if (ortho && marked) {
        float halfWidth = 1.0 / ProjMat[0][0];
        float height = 2.0 / abs(ProjMat[1][1]);

        pos.x += (c.r - 154.0) / 50.0 * halfWidth - halfWidth;
        pos.y += (height - 34.0) * c.b / 100.0;


        vec3 rgb = vec3(1.0);
        if (c.g == 250.0) rgb = vec3(85.0, 255.0, 85.0) / 255.0;
        else if (c.g == 251.0) rgb = vec3(255.0, 255.0, 85.0) / 255.0;
        else if (c.g == 252.0) rgb = vec3(255.0, 85.0, 85.0) / 255.0;
        else if (c.g == 253.0) rgb = vec3(170.0, 170.0, 170.0) / 255.0;
        col = vec4(rgb, Color.a);
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    vertexColor = col * sample_lightmap(Sampler2, UV2);
#else
    vertexColor = col;
#endif
    texCoord0 = UV0;
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
}
