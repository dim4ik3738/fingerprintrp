#version 150

#moj_import <fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler0;
uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vec4 col = Color;
    vec3 c = round(Color.rgb * 255.0);

    bool ortho = abs(ProjMat[3][3] - 1.0) < 0.001;
    bool marked = (c.r == 254.0 || c.r == 253.0) && c.g >= 252.0 && c.g <= 254.0;

    if (ortho && marked) {
        float halfWidth = 1.0 / ProjMat[0][0];
        float height = 2.0 / abs(ProjMat[1][1]);
        float marginY = c.b;

        pos.x += c.r == 254.0 ? halfWidth : -halfWidth;

        if (c.g == 254.0) {
            pos.y += marginY;
        } else if (c.g == 253.0) {
            pos.y += height * 0.5 - 17.0 + marginY;
        } else {
            pos.y += height - 34.0 - marginY;
        }

        col = vec4(1.0, 1.0, 1.0, Color.a);
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
