#version 150

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vec4 col = Color;

    vec3 c = round(Color.rgb * 255.0);
    bool ortho = abs(ProjMat[3][3] - 1.0) < 0.001;
    bool marked = (c.r == 254.0 || c.r == 253.0) && c.g >= 250.0 && c.b <= 100.0;

    if (ortho && marked) {
        float halfWidth = 1.0 / ProjMat[0][0];
        float height = 2.0 / abs(ProjMat[1][1]);

        pos.x += c.r == 254.0 ? halfWidth : -halfWidth;
        pos.y += (height - 34.0) * c.b / 100.0;

        col = vec4(1.0, 1.0, 1.0, Color.a);
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = length(Position);
    cylindricalVertexDistance = max(length(Position.xz), abs(Position.y));
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
