#version 150

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    vec4 col = Color;

    vec3 c = round(Color.rgb * 255.0);
    bool ortho = abs(ProjMat[3][3] - 1.0) < 0.001;
    bool marked = c.r >= 154.0 && c.r <= 254.0 && c.g >= 250.0 && c.g <= 254.0 && c.b <= 100.0;

    if (ortho && marked) {
        float halfWidth = 1.0 / ProjMat[0][0];
        float height = 2.0 / abs(ProjMat[1][1]);

        float t = Position.y - 3.0;
        float bestErr = 1.0e9;
        float bar = 0.0;
        float ds[8] = float[](-3.0, 0.0, 8.0, 10.0, 18.0, 20.0, 28.0, 31.0);
        for (int k = 0; k < 4; k++) {
            for (int i = 0; i < 8; i++) {
                float e = abs(t - 19.0 * float(k) - ds[i]);
                if (e < bestErr) {
                    bestErr = e;
                    bar = float(k);
                }
            }
        }
        pos.y -= 19.0 * bar;

        pos.x += (c.r - 154.0) / 50.0 * halfWidth - halfWidth; // R = 154 + x%
        pos.y += (height - 34.0) * (100.0 - c.b) / 100.0;

        // green channel picks the text colour: 250 green, 251 yellow, 252 red, 253 gray, else white
        vec3 rgb = vec3(1.0);
        if (c.g == 250.0) rgb = vec3(85.0, 255.0, 85.0) / 255.0;
        else if (c.g == 251.0) rgb = vec3(255.0, 255.0, 85.0) / 255.0;
        else if (c.g == 252.0) rgb = vec3(255.0, 85.0, 85.0) / 255.0;
        else if (c.g == 253.0) rgb = vec3(170.0, 170.0, 170.0) / 255.0;
        col = vec4(rgb, Color.a);
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = length(Position);
    cylindricalVertexDistance = max(length(Position.xz), abs(Position.y));
    vertexColor = col * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
